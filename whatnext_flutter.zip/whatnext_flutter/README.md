# WhatNext — Flutter (Android)

A full Flutter port of the WhatNext prototype: the Friends flow (setup →
recommendation engine → results → group vote) is completely implemented in
Dart. Outfits/Shopping/Learning are placeholder screens, same as the web
version.

**Important — read this first:** I don't have the Flutter SDK, Android
SDK, or network access in the sandbox I built this in, so none of this
has been compiled or run. The `lib/` folder (all the actual app logic and
UI) is hand-written Dart that I'm confident in. The `android/` folder is
native Gradle/Kotlin scaffolding that Flutter's own tooling normally
*generates* for you — I've written a standard, current version of it by
hand, but native build tooling is exactly the kind of thing that's easy
to get subtly wrong (Gradle/AGP/Kotlin version mismatches) without being
able to test it. So:

## Recommended: regenerate `android/` yourself (safest)

This guarantees a correct, version-matched native project:

```bash
flutter create --platforms=android --org com.whatnext .
```

Run this **in the project root** (where `pubspec.yaml` is). It will
generate a fresh, guaranteed-correct `android/` folder for your installed
Flutter version, without touching the `lib/` folder I already wrote.
Then:

```bash
flutter pub get
flutter run          # or: flutter build apk --release
```

## Alternative: use the `android/` folder I included

If you'd rather not run the command above, the `android/` folder here
should work as-is on a reasonably current Flutter install (Gradle 8.7,
Android Gradle Plugin 8.5, Kotlin 1.9.24, `applicationId`/namespace
`com.whatnext.app`). If `flutter pub get` or `flutter run` errors out
about Gradle/AGP/Kotlin versions, that's a version mismatch with your
local Flutter install — delete `android/` and run the `flutter create`
command above instead.

Either way:

```bash
cd whatnext_flutter
flutter pub get
flutter devices           # confirm a device/emulator is available
flutter run
```

To build a real APK:

```bash
flutter build apk --release
# output: build/app/outputs/flutter-apk/app-release.apk
```

## What's in here

```
lib/
  main.dart                 — app entry point, theme, root navigation
  theme/                    — color tokens + light/dark ThemeData
  models/                   — Activity, GroupPreferences, ScoredActivity, VoteSession
  data/                     — the 23 mock activities + interest/time option lists
  services/recommendation_engine.dart  — pure scoring logic, no UI dependency
  state/                    — AppState (ChangeNotifier) + AppStateScope
                               (a hand-rolled InheritedNotifier — no external
                               state-management package required)
  widgets/                  — FeatureCard, ChipToggle, ResultCard, VoteOptionTile
  screens/                  — Home, FriendsSetup, Results, VoteSetup, VoteRoom,
                               VoteResult, ComingSoon
android/                    — native Android project (see note above)
assets/app_icon_512.png     — placeholder app icon for your store listing later
```

`pubspec.yaml` intentionally has almost no dependencies (just
`cupertino_icons`) to minimize things that can fail to resolve on first
build. There's no local persistence yet — saved activities and results
live only for the current app run. Adding `shared_preferences` for that
is a natural next step.

## What's simulated / has no backend

Same as the web and Capacitor versions: the group-vote "friends joining"
and their votes are generated locally on-device to demonstrate the flow —
there's no real multiplayer backend. Say so in your Play Store listing's
data-safety section, since there's no server and no data leaves the
device.

## Publishing to the Play Store from here

1. Change `applicationId` in `android/app/build.gradle` (and the
   matching Kotlin package folder under
   `android/app/src/main/kotlin/`) from `com.whatnext.app` to your own.
2. Replace the placeholder icon (`android/app/src/main/res/mipmap-*/ic_launcher.png`)
   with a real one — `flutter pub run flutter_launcher_icons` is the
   standard way to generate all sizes from one source image.
3. Create a signing keystore and wire it into
   `android/app/build.gradle` (`flutter build apk` needs a real release
   signing config, not the debug one this scaffold ships with).
4. `flutter build appbundle --release` (Play Store wants an `.aab`, not
   an `.apk`).
5. Google Play Console account ($25 one-time) → create the app listing →
   fill in the data-safety form → upload the `.aab` to a testing track →
   promote to production.

If any of the above throws an error on your machine, paste it back to me
— I can help debug from the actual error even though I couldn't produce
it myself here.
