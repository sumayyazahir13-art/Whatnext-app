package com.whatnext.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
