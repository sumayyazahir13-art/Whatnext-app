import 'package:flutter/material.dart';

enum ComingSoonFeature { outfits, shopping, learning }

class ComingSoonScreen extends StatelessWidget {
  final ComingSoonFeature feature;

  const ComingSoonScreen({super.key, required this.feature});

  @override
  Widget build(BuildContext context) {
    final Map<String, String> copy = _copyFor(feature);
    return Scaffold(
      appBar: AppBar(title: const Text('Coming soon')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(copy['emoji']!, style: const TextStyle(fontSize: 44)),
              const SizedBox(height: 16),
              Text(copy['title']!, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700), textAlign: TextAlign.center),
              const SizedBox(height: 10),
              Text(
                copy['body']!,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14.5, height: 1.55, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.65)),
              ),
              const SizedBox(height: 26),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst),
                  child: const Text('Back to home'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Map<String, String> _copyFor(ComingSoonFeature f) {
    switch (f) {
      case ComingSoonFeature.outfits:
        return <String, String>{
          'emoji': '👗',
          'title': 'Outfits, coming soon',
          'body': "You'll add the clothes you own, and WhatNext will put together outfits based on occasion and weather.",
        };
      case ComingSoonFeature.shopping:
        return <String, String>{
          'emoji': '🛍️',
          'title': 'Shopping, coming soon',
          'body': "Share a product and WhatNext will lay out the price, features, reviews, and alternatives — so you can decide for yourself.",
        };
      case ComingSoonFeature.learning:
        return <String, String>{
          'emoji': '🎯',
          'title': 'Learning, coming soon',
          'body': "Tell WhatNext what you want to learn, and it'll map a path from beginner concepts to a first project.",
        };
    }
  }
}
