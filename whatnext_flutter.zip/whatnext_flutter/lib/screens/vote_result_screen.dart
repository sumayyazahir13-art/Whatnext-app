import 'package:flutter/material.dart';

import '../models/activity.dart';
import '../models/vote_session.dart';
import '../state/app_state.dart';
import '../state/app_state_scope.dart';
import '../theme/app_colors.dart';

class VoteResultScreen extends StatelessWidget {
  const VoteResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppState state = AppStateScope.of(context);
    final VoteSession? v = state.vote;
    if (v == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Group choice')),
        body: const Center(child: Text('No active vote session.')),
      );
    }

    final int maxVotes = v.options.map((VoteOption o) => o.votes).reduce((a, b) => a > b ? a : b);
    final List<VoteOption> winners = v.options.where((VoteOption o) => o.votes == maxVotes).toList();
    final VoteOption winner = winners.length == 1
        ? winners.first
        : (winners.toList()..sort((a, b) => state.scoreFor(b.activityId).compareTo(state.scoreFor(a.activityId)))).first;
    final Activity winnerActivity = state.activityById(winner.activityId);
    final int totalVotes = v.options.fold(0, (int sum, VoteOption o) => sum + o.votes);

    final List<VoteOption> sortedOptions = List<VoteOption>.from(v.options)..sort((a, b) => b.votes.compareTo(a.votes));

    return Scaffold(
      appBar: AppBar(title: const Text('Group choice')),
      body: SafeArea(
        child: ListView(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 22),
              decoration: BoxDecoration(
                color: AppColors.amberDim,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppColors.amber, width: 2),
              ),
              child: Column(
                children: <Widget>[
                  Text('GROUP CHOICE', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: AppColors.amber, letterSpacing: 0.5)),
                  const SizedBox(height: 10),
                  Text(winnerActivity.emoji, style: const TextStyle(fontSize: 46)),
                  const SizedBox(height: 8),
                  Text(winnerActivity.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700), textAlign: TextAlign.center),
                  const SizedBox(height: 4),
                  Text('${winner.votes} of $totalVotes votes', style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Text('Full tally', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            ),
            ...sortedOptions.map((VoteOption o) {
              final Activity a = state.activityById(o.activityId);
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Text('${a.emoji} ${a.name}', style: const TextStyle(fontWeight: FontWeight.w600)),
                      Text('${o.votes}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              );
            }),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: OutlinedButton(
                onPressed: () {
                  state.planAnotherVote();
                  Navigator.of(context).popUntil(ModalRoute.withName('/results'));
                },
                child: const Text('Plan another vote'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).popUntil((Route<dynamic> r) => r.isFirst),
                child: const Text('Back to home'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
