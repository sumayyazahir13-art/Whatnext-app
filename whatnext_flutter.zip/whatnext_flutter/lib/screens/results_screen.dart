import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/tags_data.dart';
import '../models/scored_activity.dart';
import '../state/app_state.dart';
import '../state/app_state_scope.dart';
import '../utils/formatters.dart';
import '../widgets/result_card.dart';
import 'vote_setup_screen.dart';

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppState state = AppStateScope.of(context);
    final List<ScoredActivity> shown = state.shownIds
        .map((String id) => state.allResults.cast<ScoredActivity?>().firstWhere(
              (ScoredActivity? r) => r!.activity.id == id,
              orElse: () => null,
            ))
        .whereType<ScoredActivity>()
        .toList();

    final TimeOption timeOpt = timeOptionFor(state.prefs.timeKey);
    final String summary = <String>[
      '${state.prefs.people} people',
      '\$${state.prefs.budget.round()}${state.prefs.budget >= 100 ? '+' : ''}/person',
      timeOpt.label,
      if (state.prefs.location.trim().isNotEmpty) state.prefs.location.trim(),
    ].join(' · ');

    return Scaffold(
      appBar: AppBar(title: const Text('Ideas for your group')),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(summary, style: TextStyle(fontSize: 13.5, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6))),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.only(top: 6, bottom: 8),
                children: shown
                    .map((ScoredActivity r) => ResultCard(
                          result: r,
                          people: state.prefs.people,
                          saved: state.savedIds.contains(r.activity.id),
                          onSave: () => state.toggleSave(r.activity.id),
                          onAnother: () {
                            final bool ok = state.showAnother(r.activity.id);
                            if (!ok) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text("That's everything that fits — nice and thorough.")),
                              );
                            }
                          },
                          onShare: () {
                            final String text =
                                '${r.activity.emoji} ${r.activity.name} — ${r.activity.description} '
                                '(${formatMoney(r.activity.costMin)}–${formatMoney(r.activity.costMax)}/person, '
                                '${formatTime(r.activity.timeMin, r.activity.timeMax)})';
                            Clipboard.setData(ClipboardData(text: text));
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Copied to clipboard')),
                            );
                          },
                        ))
                    .toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: ElevatedButton(
                onPressed: () {
                  state.beginVoteSetup();
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const VoteSetupScreen(), settings: const RouteSettings(name: '/vote-setup')),
                  );
                },
                child: const Text('Start a group vote'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
