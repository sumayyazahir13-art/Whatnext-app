import 'package:flutter/material.dart';

import '../data/tags_data.dart';
import '../state/app_state.dart';
import '../state/app_state_scope.dart';
import '../theme/app_colors.dart';
import '../widgets/chip_toggle.dart';
import 'results_screen.dart';

class FriendsSetupScreen extends StatefulWidget {
  const FriendsSetupScreen({super.key});

  @override
  State<FriendsSetupScreen> createState() => _FriendsSetupScreenState();
}

class _FriendsSetupScreenState extends State<FriendsSetupScreen> {
  final TextEditingController _locationController = TextEditingController();
  bool _controllerSeeded = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // AppStateScope.of() relies on InheritedWidget lookup, which isn't
    // available yet in initState — seed the controller here instead, once.
    if (!_controllerSeeded) {
      _locationController.text = AppStateScope.of(context).prefs.location;
      _controllerSeeded = true;
    }
  }

  @override
  void dispose() {
    _locationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AppState state = AppStateScope.of(context);
    final prefs = state.prefs;
    final ColorScheme scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(title: const Text('What are we doing?')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 12),
          children: <Widget>[
            _field(
              context,
              label: 'How many people?',
              child: Row(
                children: <Widget>[
                  IconButton.outlined(onPressed: () => state.setPeople(-1), icon: const Icon(Icons.remove)),
                  const SizedBox(width: 16),
                  Text('${prefs.people}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 16),
                  IconButton.outlined(onPressed: () => state.setPeople(1), icon: const Icon(Icons.add)),
                ],
              ),
            ),
            _field(
              context,
              label: 'Budget per person',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    '\$${prefs.budget.round()}${prefs.budget >= 100 ? '+' : ''}',
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
                  ),
                  Slider(
                    value: prefs.budget,
                    min: 0,
                    max: 100,
                    divisions: 20,
                    onChanged: state.setBudget,
                  ),
                ],
              ),
            ),
            _field(
              context,
              label: 'Location',
              child: TextField(
                controller: _locationController,
                onChanged: state.setLocation,
                decoration: const InputDecoration(
                  hintText: "Neighborhood, city, or 'near campus'",
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            _field(
              context,
              label: 'Available time',
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: kTimeOptions
                    .map((TimeOption t) => ChipToggle(
                          label: t.label,
                          selected: prefs.timeKey == t.key,
                          onTap: () => state.setTime(t.key),
                        ))
                    .toList(),
              ),
            ),
            _field(
              context,
              label: 'Indoor or outdoor?',
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: kSettingOptions
                    .map((String s) => ChipToggle(
                          label: s[0].toUpperCase() + s.substring(1),
                          selected: prefs.setting == s,
                          onTap: () => state.setSetting(s),
                        ))
                    .toList(),
              ),
            ),
            _field(
              context,
              label: 'What are you interested in?',
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: kTags
                    .map((InterestTag t) => ChipToggle(
                          label: '${t.emoji} ${t.label}',
                          selected: prefs.interests.contains(t.key),
                          onTap: () => state.toggleInterest(t.key),
                        ))
                    .toList(),
              ),
            ),
            _field(
              context,
              label: 'Anything to skip?',
              hint: "We'll leave these out entirely.",
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: kTags
                    .map((InterestTag t) => ChipToggle(
                          label: '${t.emoji} ${t.label}',
                          selected: prefs.dislikes.contains(t.key),
                          selectedColor: AppColors.coral,
                          onTap: () => state.toggleDislike(t.key),
                        ))
                    .toList(),
              ),
            ),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ElevatedButton(
                onPressed: () {
                  final bool ok = state.findIdeas();
                  if (!ok) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('That mix ruled out everything — try loosening a filter.')),
                    );
                    return;
                  }
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const ResultsScreen(), settings: const RouteSettings(name: '/results')),
                  );
                },
                child: const Text('Find ideas'),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _field(BuildContext context, {required String label, String? hint, required Widget child}) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          if (hint != null) ...<Widget>[
            const SizedBox(height: 2),
            Text(hint, style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.55))),
          ],
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}
