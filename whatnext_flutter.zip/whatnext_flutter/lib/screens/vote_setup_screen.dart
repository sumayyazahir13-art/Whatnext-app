import 'package:flutter/material.dart';

import '../models/activity.dart';
import '../state/app_state.dart';
import '../state/app_state_scope.dart';
import '../widgets/vote_option_tile.dart';
import 'vote_room_screen.dart';

class VoteSetupScreen extends StatelessWidget {
  const VoteSetupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppState state = AppStateScope.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Set up the vote')),
      body: SafeArea(
        child: Column(
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 8, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Pick 2–5 options for your friends to vote on.', style: TextStyle(color: Colors.grey)),
              ),
            ),
            Expanded(
              child: ListView(
                children: state.voteCandidateIds.map((String id) {
                  final Activity a = state.activityById(id);
                  return VoteOptionTile(
                    activity: a,
                    picked: state.voteSelection.contains(id),
                    onTap: () => state.toggleVoteCandidate(id),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: ElevatedButton(
                onPressed: state.voteSelection.length < 2
                    ? null
                    : () {
                        final bool ok = state.createRoom();
                        if (ok) {
                          Navigator.of(context).push(
                            MaterialPageRoute<void>(builder: (_) => const VoteRoomScreen(), settings: const RouteSettings(name: '/vote-room')),
                          );
                        }
                      },
                child: const Text('Create room'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
