import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../widgets/feature_card.dart';
import 'coming_soon_screen.dart';
import 'friends_setup_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 22, 20, 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('WhatNext', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, letterSpacing: -0.5)),
                  SizedBox(height: 6),
                  Text('Not sure what to do next?', style: TextStyle(fontSize: 15, color: Colors.grey)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 0.92,
                children: <Widget>[
                  FeatureCard(
                    emoji: '👯',
                    title: 'With friends',
                    subtitle: 'Decide what to do together',
                    accent: AppColors.coral,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const FriendsSetupScreen(), settings: const RouteSettings(name: '/friends-setup')),
                    ),
                  ),
                  FeatureCard(
                    emoji: '👗',
                    title: 'What to wear',
                    subtitle: 'Pick an outfit from your closet',
                    accent: AppColors.teal,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const ComingSoonScreen(feature: ComingSoonFeature.outfits)),
                    ),
                  ),
                  FeatureCard(
                    emoji: '🛍️',
                    title: 'What to buy',
                    subtitle: 'Weigh up a purchase',
                    accent: AppColors.amber,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const ComingSoonScreen(feature: ComingSoonFeature.shopping)),
                    ),
                  ),
                  FeatureCard(
                    emoji: '🎯',
                    title: 'What to learn',
                    subtitle: 'Turn a goal into a path',
                    accent: AppColors.creative,
                    onTap: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const ComingSoonScreen(feature: ComingSoonFeature.learning)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
