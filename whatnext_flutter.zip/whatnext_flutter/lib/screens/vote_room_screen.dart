import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/activity.dart';
import '../models/vote_session.dart';
import '../state/app_state.dart';
import '../state/app_state_scope.dart';
import '../widgets/vote_option_tile.dart';
import 'vote_result_screen.dart';

class VoteRoomScreen extends StatelessWidget {
  const VoteRoomScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final AppState state = AppStateScope.of(context);
    final VoteSession? v = state.vote;
    if (v == null) {
      // Defensive: shouldn't happen since this screen is only pushed after
      // createRoom() succeeds, but avoid a crash if it's ever reached cold.
      return Scaffold(
        appBar: AppBar(title: const Text('Group vote')),
        body: const Center(child: Text('No active vote session.')),
      );
    }

    final int maxVotes = v.options.isEmpty ? 1 : v.options.map((VoteOption o) => o.votes).reduce((a, b) => a > b ? a : b);
    final bool canReveal = v.userVoteId != null && !v.revealed;

    return Scaffold(
      appBar: AppBar(title: const Text('Group vote')),
      body: SafeArea(
        child: ListView(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.fromLTRB(20, 8, 20, 4),
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Theme.of(context).colorScheme.onSurface.withOpacity(0.12), width: 1.5),
              ),
              child: Column(
                children: <Widget>[
                  Text('Room code', style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6))),
                  const SizedBox(height: 4),
                  Text(v.code, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700, letterSpacing: 6)),
                  const SizedBox(height: 12),
                  OutlinedButton(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: v.code));
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Room code copied')));
                    },
                    child: const Text('Copy code'),
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 6),
              child: Align(alignment: Alignment.centerLeft, child: Text('Friends in the room', style: TextStyle(fontWeight: FontWeight.w600))),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: v.joined.isEmpty
                    ? <Widget>[const Text('Nobody yet — share the code above.', style: TextStyle(color: Colors.grey))]
                    : v.joined
                        .map((String n) => Chip(label: Text('🧑 $n'), backgroundColor: Theme.of(context).colorScheme.secondary.withOpacity(0.12)))
                        .toList(),
              ),
            ),
            if (v.joined.length < v.maxFriends) ...<Widget>[
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                child: OutlinedButton(
                  onPressed: v.joining ? null : () => state.simulateJoins(),
                  child: Text(v.joining ? 'Friends are joining…' : 'Simulate friends joining'),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 6, 20, 0),
                child: Text(
                  'This is simulated for the prototype. A real version would let friends join over the network from a shared link.',
                  style: TextStyle(fontSize: 12.5, color: Theme.of(context).colorScheme.onSurface.withOpacity(0.55)),
                ),
              ),
            ],
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 4),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(v.revealed ? 'Results' : 'Cast your vote', style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
            ),
            ...v.options.map((VoteOption o) {
              final Activity a = state.activityById(o.activityId);
              return VoteOptionTile(
                activity: a,
                picked: v.userVoteId == o.activityId,
                onTap: () => state.castVote(o.activityId),
                votes: v.revealed ? o.votes : null,
                barFraction: v.revealed ? o.votes / maxVotes : 0,
              );
            }),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
              child: v.revealed
                  ? ElevatedButton(
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => const VoteResultScreen(), settings: const RouteSettings(name: '/vote-result')),
                      ),
                      child: const Text('See group choice'),
                    )
                  : ElevatedButton(
                      onPressed: canReveal
                          ? () {
                              state.revealResults();
                            }
                          : null,
                      child: const Text('Reveal group choice'),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
