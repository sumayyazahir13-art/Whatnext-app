import '../models/activity.dart';

const List<Activity> kActivities = <Activity>[
  Activity(id: 'gaming-cafe', emoji: '🎮', name: 'Gaming Café', description: 'Spend a few hours playing games together on consoles or PCs.', costMin: 15, costMax: 25, timeMin: 2, timeMax: 3, type: 'indoor', tags: ['gaming', 'relaxing']),
  Activity(id: 'escape-room', emoji: '🔐', name: 'Escape Room', description: 'Solve puzzles as a team to break out before the clock runs out.', costMin: 25, costMax: 35, timeMin: 1, timeMax: 1.5, type: 'indoor', tags: ['gaming', 'activities']),
  Activity(id: 'bowling', emoji: '🎳', name: 'Bowling Night', description: 'A few rounds of bowling with snacks and friendly trash talk.', costMin: 15, costMax: 20, timeMin: 1.5, timeMax: 2, type: 'indoor', tags: ['activities', 'gaming']),
  Activity(id: 'picnic', emoji: '🧺', name: 'Picnic in the Park', description: 'Bring food and blankets for a relaxed afternoon outdoors.', costMin: 5, costMax: 15, timeMin: 2, timeMax: 4, type: 'outdoor', tags: ['food', 'relaxing', 'outdoors']),
  Activity(id: 'hiking', emoji: '🥾', name: 'Hiking Trail', description: 'Get moving on a scenic trail nearby, easy or challenging.', costMin: 0, costMax: 5, timeMin: 3, timeMax: 5, type: 'outdoor', tags: ['outdoors', 'activities']),
  Activity(id: 'food-truck', emoji: '🌮', name: 'Food Truck Crawl', description: 'Hop between food trucks or stalls, sampling as you go.', costMin: 20, costMax: 30, timeMin: 2, timeMax: 3, type: 'outdoor', tags: ['food']),
  Activity(id: 'cooking-class', emoji: '👩‍🍳', name: 'Cooking Class', description: 'Learn a new dish together with a hands-on group class.', costMin: 40, costMax: 60, timeMin: 2, timeMax: 3, type: 'indoor', tags: ['food', 'creative']),
  Activity(id: 'movie-theater', emoji: '🎬', name: 'Movie Night at the Theater', description: 'Catch a new release on the big screen with the group.', costMin: 12, costMax: 18, timeMin: 2, timeMax: 3, type: 'indoor', tags: ['movies', 'relaxing']),
  Activity(id: 'board-game-cafe', emoji: '♟️', name: 'Board Game Café', description: 'Pick from a wall of games and settle in with drinks.', costMin: 10, costMax: 15, timeMin: 2, timeMax: 4, type: 'indoor', tags: ['gaming', 'relaxing']),
  Activity(id: 'karaoke', emoji: '🎤', name: 'Karaoke Room', description: 'Rent a private room and take turns on the mic.', costMin: 15, costMax: 25, timeMin: 1.5, timeMax: 2, type: 'indoor', tags: ['activities', 'relaxing']),
  Activity(id: 'mini-golf', emoji: '⛳', name: 'Mini Golf', description: 'Low-stakes competitive fun on a themed course.', costMin: 10, costMax: 15, timeMin: 1, timeMax: 1.5, type: 'outdoor', tags: ['activities', 'outdoors']),
  Activity(id: 'farmers-market', emoji: '🥕', name: 'Farmers Market Stroll', description: 'Wander stalls, try samples, and pick up something fresh.', costMin: 5, costMax: 15, timeMin: 1, timeMax: 2, type: 'outdoor', tags: ['food', 'shopping', 'outdoors']),
  Activity(id: 'museum', emoji: '🖼️', name: 'Museum Visit', description: 'Explore exhibits at your own pace, then compare favorites.', costMin: 10, costMax: 20, timeMin: 2, timeMax: 3, type: 'indoor', tags: ['creative', 'activities']),
  Activity(id: 'beach', emoji: '🏖️', name: 'Beach Hangout', description: 'Sun, water, and no fixed plan — just show up and unwind.', costMin: 0, costMax: 10, timeMin: 3, timeMax: 5, type: 'outdoor', tags: ['outdoors', 'relaxing']),
  Activity(id: 'trampoline', emoji: '🤸', name: 'Trampoline Park', description: 'Bounce, dodgeball, and foam pits for burning off energy.', costMin: 15, costMax: 25, timeMin: 1.5, timeMax: 2, type: 'indoor', tags: ['activities']),
  Activity(id: 'pottery', emoji: '🎨', name: 'Pottery & Art Class', description: 'Make something with your hands in a guided studio session.', costMin: 35, costMax: 50, timeMin: 2, timeMax: 3, type: 'indoor', tags: ['creative']),
  Activity(id: 'bike-ride', emoji: '🚲', name: 'Bike Ride', description: 'Explore the area on two wheels at a relaxed pace.', costMin: 0, costMax: 10, timeMin: 1.5, timeMax: 3, type: 'outdoor', tags: ['outdoors', 'activities']),
  Activity(id: 'rooftop-cafe', emoji: '☕', name: 'Rooftop Café Hangout', description: 'Coffee, good views, and easy conversation.', costMin: 10, costMax: 20, timeMin: 1.5, timeMax: 2.5, type: 'either', tags: ['relaxing', 'food']),
  Activity(id: 'night-market', emoji: '🏮', name: 'Night Market', description: 'Street food, small stalls, and a lively evening atmosphere.', costMin: 10, costMax: 25, timeMin: 2, timeMax: 3, type: 'outdoor', tags: ['food', 'shopping']),
  Activity(id: 'comedy-show', emoji: '😂', name: 'Comedy Show', description: 'A night of live stand-up at a local venue.', costMin: 20, costMax: 30, timeMin: 1.5, timeMax: 2, type: 'indoor', tags: ['movies', 'relaxing']),
  Activity(id: 'thrift-shopping', emoji: '👕', name: 'Thrift Shopping Spree', description: 'Dig through secondhand shops for hidden finds.', costMin: 10, costMax: 40, timeMin: 2, timeMax: 3, type: 'indoor', tags: ['shopping']),
  Activity(id: 'live-music', emoji: '🎸', name: 'Live Music Gig', description: 'Catch a local band or artist at a small venue.', costMin: 20, costMax: 40, timeMin: 2, timeMax: 3, type: 'either', tags: ['activities', 'relaxing']),
  Activity(id: 'spa-day', emoji: '💆', name: 'Spa / Relaxing Day', description: 'A slow, low-key day of pampering and doing very little.', costMin: 40, costMax: 70, timeMin: 2, timeMax: 4, type: 'indoor', tags: ['relaxing']),
];

const List<String> kFriendNames = <String>['Maya', 'Leo', 'Priya', 'Sam', 'Jordan', 'Ana', 'Theo', 'Kai', 'Riley', 'Noor'];
