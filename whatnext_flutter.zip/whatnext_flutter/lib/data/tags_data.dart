/// An interest a group can select (or exclude) on the Friends setup screen.
class InterestTag {
  final String key;
  final String label;
  final String emoji;

  const InterestTag(this.key, this.label, this.emoji);
}

const List<InterestTag> kTags = <InterestTag>[
  InterestTag('food', 'Food', '🍕'),
  InterestTag('movies', 'Movies', '🎬'),
  InterestTag('gaming', 'Gaming', '🎮'),
  InterestTag('activities', 'Activities', '🏃'),
  InterestTag('outdoors', 'Outdoors', '🌳'),
  InterestTag('shopping', 'Shopping', '🛍️'),
  InterestTag('relaxing', 'Relaxing', '☕'),
  InterestTag('creative', 'Creative', '🎨'),
];

/// A selectable "how much time do we have" bracket, in hours.
class TimeOption {
  final String key;
  final String label;
  final double min;
  final double max;

  const TimeOption(this.key, this.label, this.min, this.max);
}

const List<TimeOption> kTimeOptions = <TimeOption>[
  TimeOption('short', 'Under 2 hrs', 0, 2),
  TimeOption('medium', '2–4 hrs', 2, 4),
  TimeOption('half', 'Half day', 4, 6),
  TimeOption('full', 'All day', 6, 12),
];

const List<String> kSettingOptions = <String>['indoor', 'outdoor', 'either'];

TimeOption timeOptionFor(String key) {
  return kTimeOptions.firstWhere(
    (TimeOption t) => t.key == key,
    orElse: () => kTimeOptions[1],
  );
}
