import 'package:flutter/material.dart';

import '../models/activity.dart';

/// One selectable/votable activity row, used on both the vote-setup screen
/// (as a checkbox) and the vote-room screen (as a vote target with an
/// optional live results bar).
class VoteOptionTile extends StatelessWidget {
  final Activity activity;
  final bool picked;
  final VoidCallback onTap;
  final int? votes;
  final double barFraction; // 0..1, only used when votes != null

  const VoteOptionTile({
    super.key,
    required this.activity,
    required this.picked,
    required this.onTap,
    this.votes,
    this.barFraction = 0,
  });

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: picked ? scheme.secondary.withOpacity(0.12) : scheme.surface,
          border: Border.all(color: picked ? scheme.secondary : scheme.onSurface.withOpacity(0.1), width: 2),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Container(
                      width: 22,
                      height: 22,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        color: picked ? scheme.secondary : Colors.transparent,
                        border: Border.all(color: picked ? scheme.secondary : scheme.onSurface.withOpacity(0.25), width: 2),
                      ),
                      child: picked ? const Icon(Icons.check, size: 14, color: Colors.white) : null,
                    ),
                    const SizedBox(width: 10),
                    Text('${activity.emoji} ${activity.name}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                  ],
                ),
                if (votes != null)
                  Text('$votes vote${votes == 1 ? '' : 's'}', style: TextStyle(fontWeight: FontWeight.w700, color: scheme.onSurface.withOpacity(0.6))),
              ],
            ),
            if (votes != null) ...<Widget>[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: TweenAnimationBuilder<double>(
                  tween: Tween<double>(begin: 0, end: barFraction),
                  duration: const Duration(milliseconds: 700),
                  curve: Curves.easeOutCubic,
                  builder: (BuildContext context, double value, _) {
                    return LinearProgressIndicator(
                      value: value,
                      minHeight: 9,
                      backgroundColor: scheme.onSurface.withOpacity(0.08),
                      valueColor: AlwaysStoppedAnimation<Color>(scheme.secondary),
                    );
                  },
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
