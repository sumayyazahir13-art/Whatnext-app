import 'package:flutter/material.dart';

/// A single selectable pill. Used for interests, dislikes, time, and
/// setting choices on the Friends setup screen.
class ChipToggle extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final Color selectedColor;

  const ChipToggle({
    super.key,
    required this.label,
    required this.selected,
    required this.onTap,
    this.selectedColor = const Color(0xFF0F7A6C), // AppColors.teal
  });

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          color: selected ? selectedColor : scheme.surface,
          border: Border.all(
            color: selected ? selectedColor : scheme.onSurface.withOpacity(0.12),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 14,
            color: selected ? Colors.white : scheme.onSurface,
          ),
        ),
      ),
    );
  }
}
