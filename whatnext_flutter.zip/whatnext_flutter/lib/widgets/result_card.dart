import 'package:flutter/material.dart';

import '../models/scored_activity.dart';
import '../utils/formatters.dart';

class ResultCard extends StatelessWidget {
  final ScoredActivity result;
  final int people;
  final bool saved;
  final VoidCallback onSave;
  final VoidCallback onAnother;
  final VoidCallback onShare;

  const ResultCard({
    super.key,
    required this.result,
    required this.people,
    required this.saved,
    required this.onSave,
    required this.onAnother,
    required this.onShare,
  });

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    final activity = result.activity;
    final String totalNote = people > 1
        ? ' · ~${formatMoney(activity.costMin * people)}–${formatMoney(activity.costMax * people)} total'
        : '';

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 7),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(activity.emoji, style: const TextStyle(fontSize: 26)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(activity.name, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 17)),
                      const SizedBox(height: 6),
                      Text(
                        activity.description,
                        style: TextStyle(fontSize: 13.5, color: scheme.onSurface.withOpacity(0.65), height: 1.4),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 14,
              runSpacing: 6,
              children: <Widget>[
                Text(
                  '💰 ${formatMoney(activity.costMin)}–${formatMoney(activity.costMax)}/person$totalNote',
                  style: TextStyle(fontSize: 12.5, color: scheme.onSurface.withOpacity(0.65)),
                ),
                Text(
                  '⏱ ${formatTime(activity.timeMin, activity.timeMax)}',
                  style: TextStyle(fontSize: 12.5, color: scheme.onSurface.withOpacity(0.65)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
                  decoration: BoxDecoration(
                    color: scheme.secondary.withOpacity(0.14),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    typeLabel(activity.type),
                    style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600, color: scheme.secondary),
                  ),
                ),
              ],
            ),
            if (result.reasons.isNotEmpty) ...<Widget>[
              const SizedBox(height: 12),
              Text('Why it matches', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: scheme.onSurface.withOpacity(0.6))),
              const SizedBox(height: 4),
              ...result.reasons.map(
                (String r) => Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text('✓ $r', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: scheme.secondary)),
                ),
              ),
            ],
            const SizedBox(height: 14),
            Row(
              children: <Widget>[
                Expanded(child: _ActionButton(label: saved ? '❤️ Saved' : '🤍 Save', highlighted: saved, onTap: onSave)),
                const SizedBox(width: 8),
                Expanded(child: _ActionButton(label: '🔄 Another', onTap: onAnother)),
                const SizedBox(width: 8),
                Expanded(child: _ActionButton(label: '↗ Share', onTap: onShare)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool highlighted;

  const _ActionButton({required this.label, required this.onTap, this.highlighted = false});

  @override
  Widget build(BuildContext context) {
    final ColorScheme scheme = Theme.of(context).colorScheme;
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(40),
        backgroundColor: highlighted ? scheme.primary.withOpacity(0.1) : null,
        side: BorderSide(color: highlighted ? scheme.primary : scheme.onSurface.withOpacity(0.12)),
        padding: const EdgeInsets.symmetric(horizontal: 6),
      ),
      child: FittedBox(
        child: Text(
          label,
          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: highlighted ? scheme.primary : scheme.onSurface),
        ),
      ),
    );
  }
}
