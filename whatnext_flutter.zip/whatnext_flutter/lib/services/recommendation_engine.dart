import '../data/activities_data.dart';
import '../data/tags_data.dart';
import '../models/activity.dart';
import '../models/preferences.dart';
import '../models/scored_activity.dart';

/// Pure recommendation logic, kept independent of any widget so it can be
/// unit-tested or later swapped for a real / AI-powered service.
class RecommendationEngine {
  /// Scores a single activity against a group's preferences.
  /// Returns null if the activity touches something the group asked to skip.
  static ScoredActivity? score(Activity activity, GroupPreferences prefs) {
    if (activity.tags.any((String t) => prefs.dislikes.contains(t))) {
      return null;
    }

    double score = 0;
    final List<String> reasons = <String>[];

    final List<String> matched =
        activity.tags.where((String t) => prefs.interests.contains(t)).toList();
    if (matched.isNotEmpty) {
      score += matched.length * 3;
      final String labels = matched
          .map((String m) => kTags.firstWhere((InterestTag t) => t.key == m).label)
          .join(' & ');
      reasons.add('Matches your interest in $labels');
    }

    if (activity.costMin <= prefs.budget) {
      score += 2;
      reasons.add('Within your budget');
    } else if (activity.costMin <= prefs.budget * 1.3) {
      score -= 1;
    } else {
      score -= 4;
    }

    final TimeOption timeOpt = timeOptionFor(prefs.timeKey);
    final bool overlaps = activity.timeMin <= timeOpt.max && activity.timeMax >= timeOpt.min;
    if (overlaps) {
      score += 2;
      reasons.add('Fits your available time');
    } else {
      score -= 2;
    }

    if (prefs.setting == 'either') {
      score += 0.5;
    } else if (activity.type == prefs.setting || activity.type == 'either') {
      score += 2;
      reasons.add('Good ${prefs.setting} option');
    } else {
      score -= 3;
    }

    return ScoredActivity(activity: activity, score: score, reasons: reasons);
  }

  /// Scores and ranks every activity in [pool] (defaults to the full mock
  /// dataset) against [prefs], best match first.
  static List<ScoredActivity> recommend(GroupPreferences prefs, {List<Activity>? pool}) {
    final List<Activity> list = pool ?? kActivities;
    final List<ScoredActivity> results = <ScoredActivity>[];
    for (final Activity a in list) {
      final ScoredActivity? s = score(a, prefs);
      if (s != null) results.add(s);
    }
    results.sort((ScoredActivity a, ScoredActivity b) {
      final int cmp = b.score.compareTo(a.score);
      if (cmp != 0) return cmp;
      return a.activity.name.compareTo(b.activity.name);
    });
    return results;
  }
}
