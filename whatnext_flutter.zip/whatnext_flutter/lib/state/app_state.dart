import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../data/activities_data.dart';
import '../data/tags_data.dart';
import '../models/activity.dart';
import '../models/preferences.dart';
import '../models/scored_activity.dart';
import '../models/vote_session.dart';
import '../services/recommendation_engine.dart';
import '../utils/id_generator.dart';

/// All mutable app state, in one ChangeNotifier so screens can listen via
/// [AppStateScope] without pulling in an external state-management package.
///
/// Nothing here is persisted to disk — saved activities, results, and vote
/// sessions all live only for the current app run. Adding local persistence
/// (e.g. via shared_preferences) is a good next step; see README.
class AppState extends ChangeNotifier {
  GroupPreferences prefs = GroupPreferences();

  List<ScoredActivity> allResults = <ScoredActivity>[];
  List<String> shownIds = <String>[];
  final Set<String> savedIds = <String>{};

  List<String> voteCandidateIds = <String>[];
  List<String> voteSelection = <String>[];
  VoteSession? vote;

  Activity activityById(String id) {
    return kActivities.firstWhere((Activity a) => a.id == id);
  }

  // ----- Friends setup -----

  void setPeople(int delta) {
    prefs.people = (prefs.people + delta).clamp(1, 20);
    notifyListeners();
  }

  void setBudget(double value) {
    prefs.budget = value;
    notifyListeners();
  }

  void setLocation(String value) {
    prefs.location = value;
    // No notifyListeners(): the text field already reflects what the user
    // typed, and rebuilding on every keystroke would drop cursor position.
  }

  void setTime(String key) {
    prefs.timeKey = key;
    notifyListeners();
  }

  void setSetting(String key) {
    prefs.setting = key;
    notifyListeners();
  }

  void toggleInterest(String key) {
    if (prefs.interests.contains(key)) {
      prefs.interests.remove(key);
    } else {
      prefs.interests.add(key);
      prefs.dislikes.remove(key);
    }
    notifyListeners();
  }

  void toggleDislike(String key) {
    if (prefs.dislikes.contains(key)) {
      prefs.dislikes.remove(key);
    } else {
      prefs.dislikes.add(key);
      prefs.interests.remove(key);
    }
    notifyListeners();
  }

  /// Returns false if nothing matched (e.g. everything got excluded).
  bool findIdeas() {
    allResults = RecommendationEngine.recommend(prefs);
    if (allResults.isEmpty) return false;
    shownIds = allResults.take(4).map((ScoredActivity r) => r.activity.id).toList();
    notifyListeners();
    return true;
  }

  /// Returns false if there was nothing left to swap in.
  bool showAnother(String cardId) {
    final Set<String> shownSet = shownIds.toSet();
    final ScoredActivity? next = allResults
        .cast<ScoredActivity?>()
        .firstWhere((ScoredActivity? r) => !shownSet.contains(r!.activity.id), orElse: () => null);
    if (next == null) return false;
    final int idx = shownIds.indexOf(cardId);
    shownIds[idx] = next.activity.id;
    notifyListeners();
    return true;
  }

  void toggleSave(String id) {
    if (savedIds.contains(id)) {
      savedIds.remove(id);
    } else {
      savedIds.add(id);
    }
    notifyListeners();
  }

  // ----- Group vote -----

  void beginVoteSetup() {
    final List<String> pool = <String>[...shownIds, ...savedIds];
    final Set<String> seen = <String>{};
    voteCandidateIds = pool.where((String id) => seen.add(id)).toList();
    voteSelection = shownIds.take(3).toList();
    notifyListeners();
  }

  void toggleVoteCandidate(String id) {
    if (voteSelection.contains(id)) {
      voteSelection.remove(id);
    } else if (voteSelection.length < 5) {
      voteSelection.add(id);
    }
    notifyListeners();
  }

  double scoreFor(String id) {
    final ScoredActivity? found = allResults
        .cast<ScoredActivity?>()
        .firstWhere((ScoredActivity? r) => r!.activity.id == id, orElse: () => null);
    if (found != null) return found.score;
    final ScoredActivity? s = RecommendationEngine.score(activityById(id), prefs);
    return s?.score ?? 0;
  }

  /// Returns false if fewer than two options were selected.
  bool createRoom() {
    if (voteSelection.length < 2) return false;
    vote = VoteSession(
      code: generateRoomCode(),
      options: voteSelection.map((String id) => VoteOption(activityId: id)).toList(),
      maxFriends: (prefs.people - 1).clamp(1, 6),
    );
    notifyListeners();
    return true;
  }

  Future<void> simulateJoins() async {
    final VoteSession? v = vote;
    if (v == null || v.joining) return;
    v.joining = true;
    final List<String> pool = List<String>.from(kFriendNames)..shuffle(Random());
    final int total = v.maxFriends;
    for (int i = 0; i < total; i++) {
      await Future<void>.delayed(Duration(milliseconds: 550 + Random().nextInt(500)));
      v.joined.add(pool[i]);
      notifyListeners();
    }
    v.joining = false;
    notifyListeners();
  }

  void castVote(String id) {
    final VoteSession? v = vote;
    if (v == null || v.revealed) return;
    v.userVoteId = id;
    notifyListeners();
  }

  /// Returns false if the user hasn't cast a vote yet.
  bool revealResults() {
    final VoteSession? v = vote;
    if (v == null || v.userVoteId == null) return false;

    v.options.firstWhere((VoteOption o) => o.activityId == v.userVoteId).votes += 1;

    final Random rnd = Random();
    for (int i = 0; i < v.joined.length; i++) {
      final List<double> weights =
          v.options.map((VoteOption o) => max(1.0, scoreFor(o.activityId) + 6)).toList();
      final double total = weights.fold(0.0, (double a, double b) => a + b);
      double r = rnd.nextDouble() * total;
      VoteOption chosen = v.options.first;
      for (int j = 0; j < v.options.length; j++) {
        r -= weights[j];
        if (r <= 0) {
          chosen = v.options[j];
          break;
        }
      }
      chosen.votes += 1;
    }

    v.revealed = true;
    notifyListeners();
    return true;
  }

  void planAnotherVote() {
    vote = null;
    notifyListeners();
  }

  void resetVoteSetup() {
    voteCandidateIds = <String>[];
    voteSelection = <String>[];
  }
}
