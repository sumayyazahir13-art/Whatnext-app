import 'package:flutter/widgets.dart';
import 'app_state.dart';

/// Makes a single [AppState] available to the whole widget tree without an
/// external state-management package. Call `AppStateScope.of(context)` to
/// read/mutate it; widgets that call `.of(context)` rebuild automatically
/// whenever `notifyListeners()` fires.
class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({
    super.key,
    required AppState state,
    required Widget child,
  }) : super(notifier: state, child: child);

  static AppState of(BuildContext context) {
    final AppStateScope? scope =
        context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    assert(scope != null, 'No AppStateScope found in context');
    return scope!.notifier!;
  }
}
