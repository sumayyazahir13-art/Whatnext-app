import 'package:flutter/material.dart';

import 'screens/home_screen.dart';
import 'state/app_state.dart';
import 'state/app_state_scope.dart';
import 'theme/app_theme.dart';

void main() {
  runApp(const WhatNextApp());
}

class WhatNextApp extends StatefulWidget {
  const WhatNextApp({super.key});

  @override
  State<WhatNextApp> createState() => _WhatNextAppState();
}

class _WhatNextAppState extends State<WhatNextApp> {
  final AppState _appState = AppState();

  @override
  void dispose() {
    _appState.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // AppStateScope wraps MaterialApp so every pushed route (Navigator lives
    // inside MaterialApp) can still reach AppStateScope.of(context).
    return AppStateScope(
      state: _appState,
      child: MaterialApp(
        title: 'WhatNext',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light(),
        darkTheme: AppTheme.dark(),
        themeMode: ThemeMode.system,
        home: const HomeScreen(),
      ),
    );
  }
}
