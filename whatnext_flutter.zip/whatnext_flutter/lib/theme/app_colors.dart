import 'package:flutter/material.dart';

/// Brand tokens shared by light and dark themes. Coral/teal/amber stay
/// fixed; surfaces and text swap between the two theme sets below.
class AppColors {
  static const Color coral = Color(0xFFFF5247);
  static const Color coralDim = Color(0xFFFFE7E4);
  static const Color teal = Color(0xFF0F7A6C);
  static const Color tealDim = Color(0xFFDCF3EE);
  static const Color amber = Color(0xFFE8940C);
  static const Color amberDim = Color(0xFFFFF1D6);
  static const Color creative = Color(0xFF6D5BD0);

  // Light theme surfaces
  static const Color lightInk = Color(0xFF1A1B2E);
  static const Color lightPaper = Color(0xFFF7F5F1);
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color lightMuted = Color(0xFF6B6E85);
  static const Color lightLine = Color(0x1A1A1B2E);

  // Dark theme surfaces
  static const Color darkInk = Color(0xFFF1F0F6);
  static const Color darkPaper = Color(0xFF131420);
  static const Color darkSurface = Color(0xFF1C1D2B);
  static const Color darkMuted = Color(0xFF9B9DB2);
  static const Color darkLine = Color(0x1AFFFFFF);
}
