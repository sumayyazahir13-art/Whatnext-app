/// One activity being voted on, and its running vote count.
class VoteOption {
  final String activityId;
  int votes;

  VoteOption({required this.activityId, this.votes = 0});
}

/// State for a single simulated group-vote room.
///
/// There is no real backend here: `joined` and each friend's vote are
/// generated locally to demonstrate the flow. See README for what a real
/// implementation would need.
class VoteSession {
  final String code;
  final List<VoteOption> options;
  final List<String> joined;
  final int maxFriends;
  String? userVoteId;
  bool revealed;
  bool joining;

  VoteSession({
    required this.code,
    required this.options,
    required this.maxFriends,
    List<String>? joined,
    this.userVoteId,
    this.revealed = false,
    this.joining = false,
  }) : joined = joined ?? <String>[];
}
