/// A single activity idea in the recommendation pool.
///
/// `type` is one of 'indoor', 'outdoor', or 'either'.
/// `tags` are interest keys (see [kTags] in data/tags_data.dart) used by
/// the recommendation engine to match against a group's preferences.
class Activity {
  final String id;
  final String emoji;
  final String name;
  final String description;
  final double costMin;
  final double costMax;
  final double timeMin;
  final double timeMax;
  final String type;
  final List<String> tags;

  const Activity({
    required this.id,
    required this.emoji,
    required this.name,
    required this.description,
    required this.costMin,
    required this.costMax,
    required this.timeMin,
    required this.timeMax,
    required this.type,
    required this.tags,
  });
}
