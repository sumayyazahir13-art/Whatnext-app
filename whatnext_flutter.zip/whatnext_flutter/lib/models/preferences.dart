/// The group's answers on the Friends setup screen.
///
/// `timeKey` refers to a key in [kTimeOptions] and `setting` is one of
/// 'indoor', 'outdoor', or 'either'.
class GroupPreferences {
  int people;
  double budget;
  String location;
  String timeKey;
  String setting;
  List<String> interests;
  List<String> dislikes;

  GroupPreferences({
    this.people = 4,
    this.budget = 30,
    this.location = '',
    this.timeKey = 'medium',
    this.setting = 'either',
    List<String>? interests,
    List<String>? dislikes,
  })  : interests = interests ?? <String>[],
        dislikes = dislikes ?? <String>[];
}
