import 'activity.dart';

/// An [Activity] paired with how well it matched a group's preferences,
/// and the human-readable reasons behind that score.
class ScoredActivity {
  final Activity activity;
  final double score;
  final List<String> reasons;

  const ScoredActivity({
    required this.activity,
    required this.score,
    required this.reasons,
  });
}
