import 'dart:math';

const String _kRoomCodeChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

String generateRoomCode() {
  final Random rnd = Random();
  return List<String>.generate(
    4,
    (_) => _kRoomCodeChars[rnd.nextInt(_kRoomCodeChars.length)],
  ).join();
}
