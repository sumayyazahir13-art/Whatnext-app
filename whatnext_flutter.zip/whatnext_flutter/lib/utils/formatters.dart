String formatMoney(num n) => '\$${n.round()}';

String _trim(double n) => n == n.roundToDouble() ? n.toInt().toString() : n.toStringAsFixed(1);

String formatTime(double min, double max) {
  if (min == max) return '${_trim(min)} hr';
  return '${_trim(min)}–${_trim(max)} hrs';
}

String typeLabel(String type) {
  if (type == 'either') return 'Indoor or outdoor';
  return type[0].toUpperCase() + type.substring(1);
}
